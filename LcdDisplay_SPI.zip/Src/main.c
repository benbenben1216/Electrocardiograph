/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "spi.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd_init.h"
#include "lcd.h"
#include "pic.h"
#include "delay.h"


#include "adc.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

#define LENGTH 340
__IO uint16_t ADC_DMA_ConvertedValue[LENGTH];
__IO uint32_t TransferComplete=0;

float adc_buff[LENGTH];


void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	if(TransferComplete==0)
	{
		HAL_ADC_Stop_DMA(&hadc1);
		TransferComplete=1;
		
	}
}

//int getmax(uint32_t buff[])
//{
//	int t=0,max=buff[0];
//	for(int r=0 ;r<=LCD_W ;r++)
//	{
//		if(buff[r]>=max) {
//			max=buff[r];
//			t=r;
//		}
//		
//	}
//	return t;
//	
//}


/*
	uint16_t Get_ADC_Value(void)
{
	HAL_ADC_Start( &hadc1 );
	return HAL_ADC_GetValue( &hadc1 );
	
}
uint8_t time= 0;
float level;
uint16_t x = 0 ,num = 0 ;
uint16_t y[200];

uint8_t t=0;
*/	

uint16_t x=0;
float max=0;
float min=3.30;
float set=0;
uint16_t T[2];
float bpm;
float freq;
float sample_rate;




/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
//	uint16_t x,y;
	
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI5_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
	
	HAL_ADC_Start_DMA(&hadc1 , (uint32_t*)ADC_DMA_ConvertedValue , LENGTH );
	HAL_TIM_Base_Start(&htim2);
	
	

	
	delay_init(180);			//��ʱ��ʼ��
	LCD_Init();						//LCD��ʼ��
	LCD_Fill(0,0,LCD_W,LCD_H,BLACK);	//������Ļˢ��ɫ
	
	

			
			
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		
/*		
			t++;
			if(t%5==0 && x<=240 ){
				y[0]=120;
				num++;
//				y[num]= Get_ADC_Value() /50  +120 ;
				y[num]= 3.3*Get_ADC_Value() /4096   *20 +120; 
				LCD_DrawLine( x, y[num-1], x+2, y[num], 0xf800 );
				x=x+2;	

			}

		LCD_ShowString(30,50,"f(Hz):",RED,WHITE,16,0);				
//		LCD_ShowIntNum(80,50,1,3,RED,WHITE,16);	
		LCD_ShowString(30,30,"sampling rate (Hz):",RED,WHITE,16,0);				
//		LCD_ShowIntNum(80,50,1,3,RED,WHITE,16);		
			
			
*/		


	if(TransferComplete==1)
	{
		
		for(int m=40 ; m<=LCD_W+20 ; m=m+20 )
		{
			LCD_DrawLine( m-40 , 40 , m-40 , 239 , WHITE );
			LCD_DrawLine( 0 , m,  LCD_W , m, WHITE );				
		} 
			
		for( uint16_t i= 0; i<LENGTH ; i++ )
		{
			adc_buff[i]= 3.3 *ADC_DMA_ConvertedValue[i]/ 4096 ;
			
			if(max<adc_buff[i]) max=adc_buff[i];
			if(min>adc_buff[i]) min=adc_buff[i];
			
		}
		
		LCD_ShowString(0,5, " Vmin: ",RED,BLACK,16,0);
		LCD_ShowFloatNum1(50,5,min,3,RED,BLACK,16);
		LCD_ShowString(85,5, "v",RED,BLACK,16,0);
		
		LCD_ShowString(0,23, " Vmax: ",RED,BLACK,16,0);
		LCD_ShowFloatNum1(50,23,max,3,RED,BLACK,16);
		LCD_ShowString(85,23, "v",RED,BLACK,16,0);
		
		set=max*0.5;
		x=0;
		for(int p=0;p<LENGTH ; p++){
			
			if(HAL_GPIO_ReadPin( GPIOG, GPIO_PIN_6)==1){						//KEY17
																															//Arb 0.5~2.1Hz   sin 0.6~2.4Hz
				if(adc_buff[p]>set && adc_buff[p]<adc_buff[p+1]){
					T[x]=p;
					p=p+40;	
					x++;
				}
			}
			if(HAL_GPIO_ReadPin( GPIOG, GPIO_PIN_6)==0){
																															//Arb 0.4~5.9Hz		sin  ~7Hz
				if(adc_buff[p]>set && adc_buff[p]>adc_buff[p-1]){
					T[x]=p;
					p=p+10;	
					x++;
				}																
			}
			
			if(x==2) break;
		}

		sample_rate=100;
		freq=sample_rate/(T[1]-T[0]);
		bpm=60*sample_rate/(T[1]-T[0]);
		
		LCD_ShowString(120,5,"freq: ",RED,BLACK,16,0);
		LCD_ShowFloatNum1(160,5,freq,4,RED,BLACK,16);
		LCD_ShowString(210,5,"Hz",RED,BLACK,16,0);
		
		LCD_ShowString(120,23,"bpm: ",RED,BLACK,16,0);
		LCD_ShowFloatNum1(160,23,bpm,5,RED,BLACK,16);
		


/*		if(x<LCD_W){
			LCD_DrawPoint(x ,adc_buff[x] , GREEN );
			x++;
		}
		
		else{
			for(uint16_t j=0 ; j<=LCD_W ; j++ ){
				LCD_DrawLine(j , 0 ,j , LCD_W  , WHITE );
				LCD_DrawPoint(j ,adc_buff[j] , GREEN );
			}
			x=0;
		}
*/		
if(HAL_GPIO_ReadPin( GPIOG, GPIO_PIN_7)==1)													//KEY18
{

	if(HAL_GPIO_ReadPin( GPIOG, GPIO_PIN_6)==1)
	{
		for( uint16_t x= 0; x<=LCD_W ; x++ )
		{
			LCD_DrawLine(x ,200-40*adc_buff[x] , x+1, 200-40*adc_buff[x+1], GREEN );
			if(x==LCD_W){
				
				HAL_Delay(500);
				LCD_Fill(0,0,LCD_W,LCD_H,BLACK);
				
				max=0;
			}
			
		}
	
	}
	if(HAL_GPIO_ReadPin( GPIOG, GPIO_PIN_6)==0)
	{
		for( uint16_t x= 0; x<=LCD_W ; x=x+1 )
		{
			LCD_DrawLine(x ,170-30*adc_buff[x] , x+1, 170-30*adc_buff[x+1], YELLOW );
			if(x==LCD_W){
				
				HAL_Delay(500);
				LCD_Fill(0,0,LCD_W,LCD_H,BLACK);
				
				max=0;
			}
		}
		
	}
		
		TransferComplete=0;
		HAL_ADC_Start_DMA(&hadc1 , (uint32_t*)ADC_DMA_ConvertedValue , LENGTH);

}


if(HAL_GPIO_ReadPin( GPIOG, GPIO_PIN_7)==0)
{
	if(HAL_GPIO_ReadPin( GPIOG, GPIO_PIN_6)==1)
	{	
		for( uint16_t x= 0; x<=LCD_W ; x++ )
		{
			LCD_DrawLine(x ,200-40*adc_buff[x] , x+1, 200-40*adc_buff[x+1], GREEN );
			if(x==LCD_W){
				
				max=0;
			}
		}
	}
	if(HAL_GPIO_ReadPin( GPIOG, GPIO_PIN_6)==0)
	{	
		for( uint16_t x= 0; x<=LCD_W ; x++ )
		{
			LCD_DrawLine(x ,170-30*adc_buff[x] , x+1, 170-30*adc_buff[x+1], YELLOW );
			if(x==LCD_W){
				
				max=0;
			}
		}
	}
	
	
	
		TransferComplete=1;
		HAL_ADC_Stop_DMA(&hadc1);
}

}		

/*		
		LCD_ShowString(0,0, " you qing ",RED,WHITE,32,0);		//�ַ�����ʾ����
		LCD_ShowString(30,50,"LCD_W:",RED,WHITE,16,0);				
		LCD_ShowIntNum(80,50,LCD_W,3,RED,WHITE,16);						//������ʾ����
		LCD_ShowString(130,50,"LCD_H:",RED,WHITE,16,0);
		LCD_ShowIntNum(160,50,LCD_H,3,RED,WHITE,16);
		LCD_ShowString(0,80," www.emooc.cc  ",RED,WHITE,32,0);	
*/
		
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 360;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
